package lab1_algorithm;



/**
 *
 * @author ercel
 */
public class Utils {

    // Algorithm 1: SoE (n)
    // YOUR CODE HERE
    public static int SoE(int n) {
        boolean[] A = new boolean[n + 1];
        for (int i = 0; i < n + 1; i++) {
            A[i] = true;
        }
        int count = 0;
        int sqrn = (int) Math.sqrt(n);
        for (int i = 2; i < sqrn; i++) {
            count++;
            if (A[i] == true) {
                int j = i * i;
                while (j <= n) {
                    count++;
                    A[j] = false;
                    j = j + i;
                }
            }
        }
        System.out.println(count);
        return 0;
    }

    // Algorithm 2: findAllPrimes (n)
    // YOUR CODE HERE
    public static boolean[] findAllPrimes(int n) {

        boolean[] A = new boolean[n];
        for (int i = 0; i < n; i++) {
            A[i] = true;
        }
        int counter = 0;
        for (int i = 2; i < n; i++) {
            counter++;
            for (int k = 2; k < i; k++) {
                counter++;
                if (i % k == 0) {
                    A[i] = false;
                    break;
                }
            }
        }
        System.out.println(counter);
        return A;

    }
}

package lab8_hashtable_array;

public class HashTable<T, G> {

    // Linear Probing (Closed Hashing)
    private HashEntry<Integer, String>[] table;

    public HashTable(int size) {
        table = new HashEntry[size];
    }
       
    public String get(int key) { 
        int index = hashCode()% table.length;

        if (table[index] != null && table[index].key.equals(key)) {
            return table[index].value;
        }

        System.out.println("key \"" + key + "\" not found !");
        return null;
    }
    
    private int hashFunction_1(int key) {
        String temp = String.valueOf(key);
        int first = Integer.parseInt(temp.charAt(0) + "");
        int last = Integer.parseInt(temp.charAt(temp.length() - 1) + "");

        return first + last;
    }
    
    private int hashFunction_2(int key) {
        String temp = String.valueOf(key);
        int first = Integer.parseInt(temp.charAt(1) + "");
        int last = Integer.parseInt(temp.charAt(temp.length() - 2) + "");

        return first + last;
    }
    
    // Double Hashing
    public void put(int key, String value) {
        // YOUR CODE HERE
                
       
    }

    public void printTable() {

        for (int i = 0; i < table.length; i++) {
            System.out.print("[" + i + "] ");
            if (table[i] != null) {
                System.out.println("[" + table[i].key + " : " + table[i].value + "] ");
            } else {
                System.out.println("null");
            }
        }
    }
}

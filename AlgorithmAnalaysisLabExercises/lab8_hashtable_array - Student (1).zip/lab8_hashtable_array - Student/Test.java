package lab8_hashtable_array;


public class Test {

    public static void main(String[] args) {
        // HashTable, creates an HashEntry array to store 3 elements
        HashTable<Integer, String> hashTable = new HashTable<>(13);
        
        // hashFunction gets first and last number of the key and returns the sum
        hashTable.put(18, "Ahmet Ak");
        hashTable.put(41, "İbrahim Yıldız");
        hashTable.put(22, "Merve Taşdemir");
        hashTable.put(44, "Yağmur Akar");
        
        hashTable.printTable();
    }
}

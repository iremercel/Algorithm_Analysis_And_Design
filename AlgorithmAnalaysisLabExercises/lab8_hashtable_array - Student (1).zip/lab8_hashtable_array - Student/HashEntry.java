package lab8_hashtable_array;

public class HashEntry<Integer, String> {

    Integer key;
    String value;

    public HashEntry(Integer key, String value) {
        this.key = key;
        this.value = value;
    }
}

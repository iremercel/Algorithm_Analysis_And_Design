package week2_lab;

public class Lab2 {

    public static void main(String[] args) {

        In in = new In("input_files/1Kints.txt");
        int[] a = in.readAllInts();
        Stopwatch timer = new Stopwatch();
        int count = 0;
        
        /*
        // Method 1
        count = Solution.count(a);
        StdOut.println("elapsed time = " + timer.elapsedTime());
        StdOut.println(count); // count of the number of distinct pairs that sum to exactly 0.
         */
        
        // Method 2
        timer = new Stopwatch();
        count = SolutionFast.count(a);
        StdOut.println("elapsed time = " + timer.elapsedTime());
        StdOut.println(count); // count of the number of distinct pairs that sum to exactly 0.
    }

}

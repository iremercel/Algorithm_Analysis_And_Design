package week2_lab;

public class Solution {


    // return number of distinct pairs (i, j) such that a[i] + a[j] = 0
    public static int count(int[] a) {

        // YOUR CODE HERE






        return -1;
    } 


} 

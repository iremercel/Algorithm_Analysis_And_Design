/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9_dynamic_prog_G1;

/**
 *
 * @author zkus
 */
public class ChangeMaking {

    public static int[] solve(int[] D, int n) {
       
    }
   
    
    public static void backtrace(int[] F, int[] D, int amount) {
       
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9_dynamic_prog_G1;

/**
 *
 * @author zkus
 */
public class Test {
    
    public static void main(String[] args){
        
        int amount = 9;
        int[] D = {1, 3, 5};
        int[] F = ChangeMaking.solve(D, amount);
        int min_nbr_coin = F[amount];
        System.out.println("Minimum number of coin:" + min_nbr_coin);
        System.out.print("Coin set:");
        ChangeMaking.backtrace(F, D, amount);
        System.out.println();
    }
    
}

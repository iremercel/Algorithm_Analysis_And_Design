package week4_DFS_Rec_NonRec;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

		// use your path
		Graph G= new Graph("../Labs/src/week4_DFS_Rec_NonRec/edges2.txt", false); // directed: false
		
		System.out.println(G); // Adjacency matrix will be printed out. 
		
		int start;
		int end;
		System.out.print("Enter start node: ");
		Scanner scanner = new Scanner(System.in);
		start = scanner.nextInt();
		
		System.out.println("Graph Traversal with DFS using recursion");
		DFS dfSearcher= new DFS(G.getAdjList()); // Creates a new DFS object
		dfSearcher.dfs(start);
		
		System.out.println();
		System.out.println("Graph connected: "+ dfSearcher.isConnected()); // assumes that dfs method has been called!
	}

}

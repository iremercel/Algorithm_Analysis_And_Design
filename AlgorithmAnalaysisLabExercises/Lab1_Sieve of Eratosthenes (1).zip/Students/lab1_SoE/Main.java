/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab1_SoE;

/**
 *
 * @author zkus
 */
public class Main {
    public static void main(String[] args) {
        
        Utils.SoE(10);
        Utils.findAllPrimes(10);
        
    }
}

package lab1_SoE;

public class Utils {

    // Algorithm 1: SoE (n)
        // YOUR CODE HERE


    // Algorithm 2: findAllPrimes (n)
        // YOUR CODE HERE


   
}



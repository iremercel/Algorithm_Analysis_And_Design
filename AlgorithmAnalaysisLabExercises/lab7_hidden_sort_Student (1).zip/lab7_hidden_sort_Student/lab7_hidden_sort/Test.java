package lab7_hidden_sort;

public class Test {

    public static void main(String[] args) {
        int[] list = {5, 20, 39, 4, 4, 81, 42, 42, 24, 1};
        int[] sortedList = new int[list.length];
        
        HiddenSort cs = new HiddenSort();
        cs.sort(list, sortedList);
        
        System.out.println("Sorted Array in Ascending Order: ");
        for (int i = 0; i < sortedList.length; i++) {
            System.out.print(sortedList[i] + " ");
        }
        
        // Negative Sort
        int[] negativeList = {5, 10, 2, 8, -1, 1, 3, -3, -3};
        int[] negativeSortedList = new int[negativeList.length];
        cs.negativeSort(negativeList, negativeSortedList);
        
        System.out.println("Sorted Array in Ascending Order: ");
        for (int i = 0; i < negativeSortedList.length; i++) {
            System.out.print(negativeSortedList[i] + " ");
        }
    }

}

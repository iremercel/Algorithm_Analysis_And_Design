/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_hidden_sort;

/**
 *
 * @author ZekiKus
 */
public class HiddenSort {

    public void sort(int[] A, int[] B) {

        // YOUR CODE HERE
    }
    
    public void negativeSort(int[] A, int[] B) {

        // YOUR CODE HERE
    }
}
